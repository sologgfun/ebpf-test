// Package gen contains utilities to generate Go bindings for eBPF ELF files.
package gen
