// Package asm is an assembler for eBPF bytecode.
package asm
