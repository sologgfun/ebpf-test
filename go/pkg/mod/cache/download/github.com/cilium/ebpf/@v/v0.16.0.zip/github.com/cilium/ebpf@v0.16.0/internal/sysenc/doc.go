// Package sysenc provides efficient conversion of Go values to system
// call interfaces.
package sysenc
